Baaजार Android APK project

This is an Android WebView wrapper around the Baaजार starter grocery app.
Package: com.baazaar.kirana
Demo Admin PIN: 1234

IMPORTANT
- This project is a buildable source project, not a precompiled APK.
- The app stores products, cart and orders locally on this phone/browser storage. It does NOT sync orders to other customers' phones or to a separate admin phone.
- For a real multi-customer launch, add a shared backend/database and secure admin authentication before publishing.
- Demo PIN must be changed/replaced before public use.

BUILD APK FROM AN ANDROID PHONE (free cloud build)
1. Download and extract this ZIP.
2. Create/sign in to a GitHub account and create a new repository named Baazaar.
3. Upload all extracted files/folders into the repository root (including hidden .github folder). Easiest: use GitHub website's Add file / Upload files; ensure .github/workflows/build-apk.yml is included.
4. Open repository > Actions. If prompted, enable Actions.
5. Run workflow "Build Baaजार APK" using Run workflow, or push files to main.
6. When it completes, open the workflow run, scroll to Artifacts and download Baazaar-debug-apk.
7. Extract artifact ZIP to find app-debug.apk. Open it on Android and allow install from this source if prompted.

The workflow uses Gradle and Android SDK in GitHub-hosted build runners. The first build may take a few minutes.
