Baaजार Kirana App — Starter package

WHAT WORKS
- Mobile-friendly grocery storefront
- Search products, add to cart, quantity changes
- Customer name, phone, address and checkout
- Admin demo PIN: 1234
- Add products, change price, turn products Live/Off
- Order list and order status management
- Saves data in the browser's localStorage on the same device/browser

IMPORTANT LIMITATION
This is a working single-device starter/PWA-style web app, NOT a deployed multi-user online store or APK yet. Data is not shared between customer phones and your admin phone. Real online ordering needs a hosted backend/database, secure admin authentication, hosting, and then an Android APK wrapper/build. Do not use demo PIN 1234 for a public launch.

HOW TO TRY
1. Extract the ZIP.
2. Open index.html in a browser.
3. Tap Admin and enter 1234.
4. Add products or use Live/Off buttons.
5. Test customer checkout from the Shop tab.

NEXT STEP FOR A REAL ONLINE VERSION
Connect Firebase/Supabase (or equivalent) for shared products and orders, secure admin login, and deploy the customer storefront. Payment gateway can be added later; cash on delivery can be the first option.
